import React, { useState } from 'react';

const pageStyle = {
  fontFamily: "sans-serif",
  background: '#0d0d0d',
  color: '#f0f0f0',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  alignItems: 'center',
  height: '100vh',
  margin: 0,
};

const formStyle = {
  background: '#1a1a1a',
  padding: '30px 40px',
  borderRadius: '12px',
  boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
  width: '340px',
  border: '1px solid #FFD700',
  textAlign: 'center',
  boxSizing: 'border-box'
};

const headingStyle = {
  color: '#FFD700',
  marginBottom: '25px',
  fontWeight: '700',
};

const inputStyle = {
  display: 'block',
  margin: '15px 0',
  padding: '14px',
  width: '100%',
  boxSizing: 'border-box',
  background: '#2c2c2c',
  border: '1px solid #444',
  borderRadius: '8px',
  color: '#f0f0f0',
  fontSize: '1rem',
};

const buttonStyle = {
  padding: '14px',
  marginTop: '10px',
  background: '#FFD700',
  color: '#0d0d0d',
  border: 'none',
  borderRadius: '8px',
  width: '100%',
  fontWeight: '700',
  fontSize: '1rem',
  cursor: 'pointer',
};

const switcherContainerStyle = {
  marginTop: '20px',
  textAlign: 'center',
};

const switcherButtonStyle = {
  background: 'none',
  border: 'none',
  color: '#FFD700',
  cursor: 'pointer',
  marginLeft: '8px',
  fontWeight: '700',
  fontSize: '1rem',
  padding: '0'
};

function AuthForm({ isLogin }) {
  return (
    <div style={formStyle}>
      <h2 style={headingStyle}>{isLogin ? "Login" : "Sign Up"}</h2>
      <input placeholder="Username" style={inputStyle} />
      <input placeholder="Password" type="password" style={inputStyle} />
      <button style={buttonStyle}>{isLogin ? "Login" : "Sign Up"}</button>
    </div>
  );
}

export default function App() {
  const [loginMode, setLoginMode] = useState(true);
  return (
    <div style={pageStyle}>
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
      <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet" />
      <AuthForm isLogin={loginMode} />
      <p style={switcherContainerStyle}>
        {loginMode ? "No account?" : "Already have an account?"}
        <button onClick={() => setLoginMode(!loginMode)} style={switcherButtonStyle}>
          {loginMode ? "Sign Up" : "Login"}
        </button>
      </p>
    </div>
  );
} 