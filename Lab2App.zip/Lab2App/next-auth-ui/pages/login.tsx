import React from 'react';

const pageStyle = {
    fontFamily: "'Poppins', sans-serif",
    background: '#0d0d0d',
    color: '#f0f0f0',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    margin: 0,
};

const formStyle = {
    background: '#1a1a1a',
    padding: '30px 40px',
    borderRadius: '12px',
    boxShadow: '0 10px 30px rgba(0,0,0,0.5)',
    width: '340px',
    border: '1px solid #FFD700',
    textAlign: 'center',
    boxSizing: 'border-box'
};

const headingStyle = {
    color: '#FFD700',
    marginBottom: '25px',
    fontWeight: '700',
};

const inputStyle = {
    display: 'block',
    margin: '15px 0',
    padding: '14px',
    width: '100%',
    boxSizing: 'border-box',
    background: '#2c2c2c',
    border: '1px solid #444',
    borderRadius: '8px',
    color: '#f0f0f0',
    fontSize: '1rem',
    fontFamily: "'Poppins', sans-serif",
};

const buttonStyle = {
    padding: '14px',
    marginTop: '10px',
    background: '#FFD700',
    color: '#0d0d0d',
    border: 'none',
    borderRadius: '8px',
    width: '100%',
    fontWeight: '700',
    fontSize: '1rem',
    cursor: 'pointer',
    fontFamily: "'Poppins', sans-serif",
};

export default function LoginPage() {
  return (
    <div style={pageStyle}>
        {/* We can't add <link> tags here directly in Next.js pages. This should be done in a custom _app.tsx or _document.tsx file. 
            For this lab, we'll rely on the font being available or omit direct font import in this file. 
            The font-family will fall back to sans-serif if Poppins isn't loaded globally. */}
      <div style={formStyle}>
        <h2 style={headingStyle}>Login</h2>
        <input placeholder="Username" style={inputStyle} />
        <input placeholder="Password" type="password" style={inputStyle} />
        <button style={buttonStyle}>Login</button>
      </div>
    </div>
  );
} 